//
//  UIApplication+PLVImageViewController.h
//
//  Created by markelsoft on 4/14/15.
//  Copyright MarkelSoft, Inc. 2015. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIApplication (PLVImageViewController)

- (BOOL)PLV_usesViewControllerBasedStatusBarAppearance;

@end
