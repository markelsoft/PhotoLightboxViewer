//
//  main.m
//  AddressFind
//
//  Created by markelsoft on 7/22/11.
//  Copyright 2011 MarkelSoft, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    @autoreleasepool {
        int retVal = UIApplicationMain(argc, argv, nil, nil);
        return retVal;
    }
}
