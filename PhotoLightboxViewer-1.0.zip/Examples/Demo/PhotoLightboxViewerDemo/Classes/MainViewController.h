//
//  MainViewController.h
//  PhotoLightboxViewerDemo
//
//  Created v1.0 by markelsoft on 04/15/2015.
//  Copyright 2015 MarkelSoft, Inc. All rights reserved.
//

#import "PhotoLightboxViewer.h"

@interface MainViewController : UIViewController {
	
    int screenWidth;
    int screenHeight;
}

@end
